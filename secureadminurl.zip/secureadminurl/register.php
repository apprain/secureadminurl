<?php
/**
 * appRain CMF
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */

class Component_SecureAdminURL_Register extends appRain_Base_Component
{
    public function init()
    {
		if(App::Config()->Setting('secureadminurl_status','Inactive') == 'Active' && App::Config()->Setting('secureadminurl_urlpart','') != ''){
		
			$this->VerifyAddress();

			App::Module('Hook')
				->setHookName('URIManager')
				->setAction("on_initialize")
				->Register(get_class($this),"register_newrole");	
		}
			App::Module('Hook')
				->setHookName('Sitesettings')
				->setAction("register_definition")
				->Register(get_class($this), "register_sitesettings_defination");		

			App::Module('Hook')
				->setHookName('InterfaceBuilder')
				->setAction("update_definition")
				->Register(get_class($this),"interfacebuilder_update_definition");		
		
    }
	
	public function VerifyAddress(){
	
		
		$str = App::Config()->Setting('secureadminurl_urlpart','');
		
		
		$_GET['basicrout'] = isset($_GET['basicrout']) ? $_GET['basicrout'] : '';
		
		if(substr($_GET['basicrout'],0,12) == 'admin/system'){
			$RoutedBySecAdURL = App::Session()->Read('RoutedBySecAdURL');
			if(empty($RoutedBySecAdURL)){
				App::__transfer('/');
				exit;
			}
		}
		
		if($_GET['basicrout'] == $str){
			App::Session()->Write('RoutedBySecAdURL','Yes');
		}
	}

    public function init_on_install(){}

    public function init_on_uninstall(){}
    
    public function register_newrole($def=null)
    {
		$str = App::Config()->Setting('secureadminurl_urlpart','');
		
        $def['pagerouter'][] = array("actual"=>Array("admin","system"),"virtual"=>Array($str));
		
        return $def;
    }

	public function register_sitesettings_defination()
    {
        $srcpaths = Array();
        $srcpaths[] = $this->attachMyPath('sitesettings/settings.xml');

        return array('filepaths' => $srcpaths);
    }

	public function interfacebuilder_update_definition($send)
    {
        if(isset($send['component']['child']))
        {
            $send['component']['child'][] = Array(
                "title"=>"Secure Amin URL",
                "items"=>Array(
					array(
                        "title"=>"Preference",
                        "link"=>"/admin/config/secureadminurl"
                    )),
                    "adminicon" => array("type"=>"filePath",'location'=>'/component/secureadminurl/icon/logo.jpg'));
					
            return $send;
        }
    }	
}